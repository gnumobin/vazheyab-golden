const rectVolumeY=10,rectVolumeX=13,windowShade=document.querySelector("canvas#windowShade"),WS_CTX=windowShade.getContext("2d");WS_CTX.fillStyle="#CED9E3",WS_CTX.fillRect(13,10,4,22),WS_CTX.fillRect(13,40,4,22),WS_CTX.fillRect(13,70,4,22),WS_CTX.fillRect(13,100,4,22),WS_CTX.fillRect(13,130,4,22),WS_CTX.fillRect(13,160,4,22),WS_CTX.fillRect(13,190,4,22),
//! Create Circle of the end window shade
WS_CTX.beginPath(),WS_CTX.arc(15,230,13,0,2*Math.PI,!0),WS_CTX.fillStyle="#1CB0F688",WS_CTX.fill(),
//! Create Circle of the end window shade
WS_CTX.beginPath(),WS_CTX.arc(15,230,9,0,2*Math.PI,!0),WS_CTX.fillStyle="#1CB0F6",WS_CTX.fill();