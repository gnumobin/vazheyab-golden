// Class
// const observer = new Observer();
const transmitter = new Transmitter();
const api = new API();
const clipboard = new Clipboard();

// Call The All JS Codes
My_JavaScript();
